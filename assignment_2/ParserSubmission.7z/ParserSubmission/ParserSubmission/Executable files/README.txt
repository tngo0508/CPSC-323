INSTRUCTION

WINDOWS OS
- Put all file.txt files that you want to test into same folder with the executable file (Project2.exe)
- Run the program  by double-click on �Project2.exe�
- Type txt file name and see the result on �output.txt� or on DOS/WINDOWS screen.

**** Important: Make sure you put the file.txt and Project2.exe in the same place in order to run the program successfully.

