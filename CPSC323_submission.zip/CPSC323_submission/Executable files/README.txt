INSTRUCTION

WINDOWS OS
- Put all file.txt files that you want to test into same folder with the executable file (project1.exe)
- Run the program  by double-click on �project1.exe�
- Type txt file name and see the result on �output.txt� or on DOS/WINDOWS screen.

**** Important: Make sure you put the file.txt and project1.exe in the same place in order to run the program successfully.

DEBIAN-BASED LINUX OS
- Use Terminal and go to the directory of the project (Make sure file.txt and a.out in the same directory)
- Type chmod u+x a.out to change permission to execute, then press �enter� key
- Type ./a.out , then press �enter� key to run the program

Example:
	$ chmod u+x a.out
	$ ./a.out
	
*Optional: you may recompile source code if any errors occur by going to �Source code� folder/directory and execute these commands:
	$ sh project.sh
	$ ./a.out

- Type txt file name and see the result  on �output.txt� or on terminal screen. 

**Note: quick view the content of output.txt on terminal by using
	$ cat output.txt
