INSTRUCTION

WINDOWS OS
- Put all file.txt files that you want to test into same folder with the executable file (project1.exe)
- Run the program  by double-click on �project1.exe�
- Type txt file name and see the result on �output.txt� or on DOS/WINDOWS screen.

**** Important: Make sure you put the file.txt and project1.exe in the same place in order to run the program successfully.

DEBIAN-BASED LINUX OS
- Make sure file.txt in Linux directory
- Execute these commands in "Linux" directory:
	$ sh project.sh
	$ ./a.out

- Type txt file name and see the result  on �output.txt� or on terminal screen. 

**Note: quick view the content of output.txt on terminal by using
	$ cat output.txt
